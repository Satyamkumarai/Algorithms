# Primes Pickle
## Contains a pickle file that has all prime numbers lessthan 10000000 as keys and their order as values..